
export default function Thanks(){
  return (
    <div style={{minHeight:'70vh',display:'grid',placeItems:'center',textAlign:'center'}}>
      <div>
        <h1>Дякую! Заявку надіслано ✅</h1>
        <p style={{opacity:.8}}>Я відповім найближчим часом. Також можна написати у WhatsApp або Telegram.</p>
      </div>
    </div>
  )
}
